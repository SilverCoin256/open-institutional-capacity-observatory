# Citation

Use the repository citation metadata until a DOI has been minted.

```bibtex
@software{oico_2026,
  title = {Open Institutional Capacity Observatory},
  author = {Gupta, Shaurya},
  year = {2026},
  version = {1.1.1},
  note = {Final frozen technical release with exploratory Study 1. DOI pending.}
}
```

## What To Cite

- Cite the software when using the package, CLI, metrics, benchmarks, or figures.
- Cite the dataset release when using processed tables.
- Cite original public sources when making substantive claims about EOIR, USCIS, CFPB, SEC EDGAR, or source policy documents.

## DOI Policy

Do not claim a DOI until one exists. After a DOI is minted, update `CITATION.cff`, `codemeta.json`, release notes, and this page.
